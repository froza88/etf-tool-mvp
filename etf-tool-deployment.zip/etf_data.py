#!/usr/bin/env python3
"""
ETF数据模块 - 从etf_complete_130.json加载数据
"""
import json
from pathlib import Path

# 加载ETF数据
DATA_FILE = Path(__file__).parent / "etf_complete_130.json"

def _load_etfs():
    """加载ETF数据并转换为标准格式"""
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        raw_etfs = json.load(f)
    
    etfs = []
    for etf in raw_etfs:
        # 转换字段映射
        transformed = {
            "code": etf.get("symbol_id", ""),
            "name": etf.get("name", ""),
            "type": "股票型",  # 默认值
            "scale": etf.get("market_cap_total", 0) / 1e8 if etf.get("market_cap_total") else 0,  # 转换为亿元
            "fee": 0.6,  # 默认值，需从其他数据源获取
            "management_fee": 0.5,
            "custody_fee": 0.1,
            "tracking_error": 0.02,  # 默认值
            "year_1_return": etf.get("change_rate_1y", 0) / 100 if etf.get("change_rate_1y") else 0,
            "year_3_return": etf.get("change_rate_3y", 0) / 100 if etf.get("change_rate_3y") else 0,
            "max_drawdown": etf.get("max_drawdown", 0),
            "sharpe_ratio": 0.0,  # 需计算
            "launch_date": etf.get("issue_date", ""),
            "issuer": etf.get("manager", ""),
            "underlying": etf.get("tracking_index_symkey", ""),
            "top_holdings": [],  # 需从其他数据源获取
            "volume": etf.get("turnover", 0) / 1e8 if etf.get("turnover") else 0,  # 转换为亿元
            "category": "宽基" if "沪深300" in etf.get("name", "") or "中证500" in etf.get("name", "") else "行业",
        }
        etfs.append(transformed)
    
    return etfs

# 缓存ETF数据
_ETFs = None

def get_all_etfs():
    """获取所有ETF"""
    global _ETFs
    if _ETFs is None:
        _ETFs = _load_etfs()
    return _ETFs

def get_etf_by_code(code):
    """根据代码获取ETF"""
    etfs = get_all_etfs()
    for etf in etfs:
        if etf["code"] == code:
            return etf
    return None

def filter_etfs(filters):
    """筛选ETF"""
    etfs = get_all_etfs()
    result = []
    
    for etf in etfs:
        # 类型筛选
        if "type" in filters and filters["type"]:
            if etf["type"] != filters["type"]:
                continue
        
        # 规模筛选
        if "scale_min" in filters and filters["scale_min"]:
            if etf["scale"] < float(filters["scale_min"]):
                continue
        if "scale_max" in filters and filters["scale_max"]:
            if etf["scale"] > float(filters["scale_max"]):
                continue
        
        # 费率筛选
        if "fee_max" in filters and filters["fee_max"]:
            if etf["fee"] > float(filters["fee_max"]):
                continue
        
        # 收益率筛选
        if "return_min" in filters and filters["return_min"]:
            if etf["year_1_return"] < float(filters["return_min"]):
                continue
        
        # 分类筛选
        if "category" in filters and filters["category"]:
            if etf["category"] != filters["category"]:
                continue
        
        # 关键词筛选
        if "keyword" in filters and filters["keyword"]:
            if filters["keyword"].lower() not in etf["name"].lower():
                continue
        
        result.append(etf)
    
    return result
